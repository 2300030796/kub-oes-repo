package com.klef.sdp.service;

import com.klef.sdp.model.*;
import com.klef.sdp.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

@Service
public class TeacherServiceImpl implements TeacherService {

    @Autowired
    private TeacherRepository teacherRepo;

    @Autowired
    private ExamRepository examRepo;

    @Autowired
    private ResultRepository resultRepo;

    @Autowired
    private StudentRepository studentRepo;

    @Autowired
    private QuestionRepository questionRepo;

    private final String UPLOAD_DIR = "uploads/teachers"; // folder inside project root

    @Override
    public Exam scheduleExam(Exam exam) {
        return examRepo.save(exam);
    }

    @Override
    public List<Exam> viewExams() {
        return examRepo.findAll();
    }

    @Override
    public Result addResult(Result result) {
        return resultRepo.save(result);
    }

    @Override
    public List<Result> viewResults() {
        return resultRepo.findAll();
    }

    @Override
    public Student addStudent(Student student) {
        return studentRepo.save(student);
    }

    @Override
    public List<Student> viewStudents() {
        return studentRepo.findAll();
    }

    @Override
    public Teacher getProfile(Long id) {
        return teacherRepo.findById(id).orElse(null);
    }

    @Override
    public Teacher updateProfile(Teacher teacher) {
        Teacher existing = teacherRepo.findById(teacher.getId()).orElseThrow(() ->
                new RuntimeException("Teacher not found"));

        existing.setPhone(teacher.getPhone());
        existing.setDepartment(teacher.getDepartment());
        existing.setQualification(teacher.getQualification());

        return teacherRepo.save(existing);
    }

    // NEW: handle profile picture upload
    @Override
    public Teacher updateProfileImage(Long id, MultipartFile profilePic) {
        Teacher teacher = teacherRepo.findById(id).orElseThrow(() ->
                new RuntimeException("Teacher not found"));

        try {
            // create directory if not exists
            Files.createDirectories(Paths.get(UPLOAD_DIR));

            String filename = System.currentTimeMillis() + "_" + profilePic.getOriginalFilename();
            String filepath = UPLOAD_DIR + File.separator + filename;

            // save file locally
            profilePic.transferTo(new File(filepath));

            // save filename in DB (relative path)
            teacher.setProfilePic("teachers/" + filename);

            return teacherRepo.save(teacher);

        } catch (IOException e) {
            throw new RuntimeException("Failed to upload profile picture", e);
        }
    }

    @Override
    public List<Question> addQuestions(Long examId, List<Question> questions) {
        Exam exam = examRepo.findById(examId).orElse(null);
        if (exam == null) return null;

        for (Question q : questions) {
            q.setExam(exam);
        }

        return questionRepo.saveAll(questions);
    }

    @Override
    public List<Question> getQuestionsByExam(Long examId) {
        return questionRepo.findByExamId(examId);
    }
}
