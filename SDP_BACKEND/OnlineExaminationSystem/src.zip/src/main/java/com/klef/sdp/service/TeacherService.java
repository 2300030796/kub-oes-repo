package com.klef.sdp.service;

import com.klef.sdp.model.*;
import java.util.List;
import org.springframework.web.multipart.MultipartFile;

public interface TeacherService {
    Exam scheduleExam(Exam exam);
    List<Exam> viewExams();

    Result addResult(Result result);
    List<Result> viewResults();

    Student addStudent(Student student);
    List<Student> viewStudents();

    Teacher getProfile(Long id);
    Teacher updateProfile(Teacher teacher);

    // NEW: update profile picture
    Teacher updateProfileImage(Long id, MultipartFile profilePic);


    List<Question> addQuestions(Long examId, List<Question> questions);
    List<Question> getQuestionsByExam(Long examId);
}
