package com.klef.sdp.service;

import com.klef.sdp.model.*;
import java.util.List;

public interface StudentService {
    Student getProfile(Long id);
    Student updateProfile(Student student);

    List<Exam> viewUpcomingExams();
    List<Result> viewResults(Long studentId);
    Student getByEmail(String email);

}
