package com.klef.sdp.controller;

import com.klef.sdp.model.*;
import com.klef.sdp.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@CrossOrigin("*")
@RestController
@RequestMapping("/student")
public class StudentController {

    @Autowired
    private StudentService studentService;
    
    @PostMapping("/login")
    public ResponseEntity<?> loginStudent(@RequestBody Student student) {
        Student existing = studentService.getByEmail(student.getEmail());
        if (existing != null && existing.getPassword().equals(student.getPassword())) {
            return ResponseEntity.ok(Map.of("success", true, "student", existing));
        }
        return ResponseEntity.ok(Map.of("success", false, "message", "Invalid credentials"));
    }

    @GetMapping("/profile/{id}")
    public Student getProfile(@PathVariable Long id) { return studentService.getProfile(id); }
    
    

    @PutMapping("/profile")
    public Student updateProfile(@RequestBody Student student) { return studentService.updateProfile(student); }

    @GetMapping("/exams/upcoming")
    public List<Exam> viewUpcomingExams() { return studentService.viewUpcomingExams(); }

    @GetMapping("/results/{id}")
    public List<Result> viewResults(@PathVariable Long id) { return studentService.viewResults(id); }
    
}
