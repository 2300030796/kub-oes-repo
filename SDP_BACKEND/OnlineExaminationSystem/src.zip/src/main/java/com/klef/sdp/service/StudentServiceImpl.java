package com.klef.sdp.service;

import com.klef.sdp.model.*;
import com.klef.sdp.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepository studentRepo;
    @Autowired
    private ExamRepository examRepo;
    @Autowired
    private ResultRepository resultRepo;

    @Override
    public Student getProfile(Long id) { return studentRepo.findById(id).orElse(null); }

    @Override
    public Student updateProfile(Student student) { return studentRepo.save(student); }

    @Override
    public List<Exam> viewUpcomingExams() { return examRepo.findAll(); }

    @Override
    public List<Result> viewResults(Long studentId) {
        return resultRepo.findAll().stream()
                .filter(r -> r.getStudent().getId().equals(studentId))
                .toList();
    }
    @Override
    public Student getByEmail(String email) {
        return studentRepo.findByEmail(email);
    }

}
