const config = 
{
    "url":"http://localhost:30796"
}

export default config